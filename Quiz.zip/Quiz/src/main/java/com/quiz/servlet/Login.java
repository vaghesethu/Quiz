package com.quiz.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.quiz.Dao.QuizDao;
import com.quiz.Dao.QuizUtil;
import com.quiz.bean.QuizBean;

@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Login() {
        super();
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("name");
		String password=request.getParameter("password");
        QuizDao dao=new QuizDao();
        Connection con=dao.check(name, password);
        QuizBean bean=null;
        try {
			bean=QuizUtil.findUser(con, name, password);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
        if(bean==null)
        {
        	response.sendRedirect("login.jsp");	
        }else{ 
        	HttpSession session=request.getSession();
        	session.setAttribute("user",bean);
			response.sendRedirect("quiz.jsp");
        }		
	}

}

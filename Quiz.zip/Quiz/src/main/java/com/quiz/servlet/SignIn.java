package com.quiz.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.quiz.Dao.QuizDao;
import com.quiz.Dao.QuizUtil;
import com.quiz.bean.QuizBean;

@WebServlet("/SignIn")
public class SignIn extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public SignIn() {
        super();
        
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		QuizBean New=new QuizBean();
		New.setName(name);
		New.setPassword(password);
		QuizDao dao=new QuizDao();
		try {
			Connection con=dao.getcon();
			QuizUtil.UpdateUser(con,New);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		response.sendRedirect("index.jsp");
	}

}

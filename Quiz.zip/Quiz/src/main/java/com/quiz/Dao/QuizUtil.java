package com.quiz.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.quiz.bean.QuizBean;
public class QuizUtil {
	public static QuizBean findUser(Connection con,String name, String password) throws SQLException
	{
 
        String sql = "Select * from quiz where Name=? and Password=? "; 
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, name);
        pstm.setString(2, password);
        ResultSet rs = pstm.executeQuery();
 
        if (rs.next()) {
            QuizBean bean=new QuizBean();
            bean.setName(name);
            bean.setPassword(password);
            return bean;
        }
        return null;
    }
	public static void UpdateUser(Connection con, QuizBean bean) throws SQLException {
		String sql = "Insert into quiz values(?,?);"; 
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1,bean.getName());
        pstm.setString(2,bean.getPassword());
        pstm.executeUpdate();
	}
}

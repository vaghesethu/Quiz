package com.quiz.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QuizDao {
	
	String url="jdbc:mysql://localhost:3306/practice";
	String username="root";
	String pass="abc";
	public Connection check(String name,String password) 
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,pass);
			String sql="select * from quiz where name=? and password=BINARY? ";
			 PreparedStatement st=con.prepareStatement(sql);
			 st.setString(1, name);
			 st.setString(2, password);
			 ResultSet rs=st.executeQuery();
			 if(rs.next())
			 {
				 return con;
			 }	 
			 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public Connection getcon() throws SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,pass);
			return con;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
		
	}

}
